#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include <time.h>
#include "msort.h"
#include "fibbo.h"
int main()
{
        int number,numsearch,i;
        int arr[] = {64, 34, 25, 12, 22, 11, 90};
        int n = sizeof(arr)/sizeof(arr[0]);
        printf("sorted array is:");
       	MergeSort(arr,n);   //sorting of array
	for(i=0;i<n;i++)
            printf("%d, ",arr[i]);
	printf("\n");
        printf("Enter a number which you want to search:");
        scanf("%d",&numsearch);
	linearsearch(arr,numsearch,n);
	printf("Enter a number upto you want to print fibannico series:"); 
	scanf("%d",&number);
	printf("Fibonacci terms: \n");
	fibbo(number);
	return 0;
}

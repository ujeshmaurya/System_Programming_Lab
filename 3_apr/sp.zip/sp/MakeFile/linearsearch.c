#include<stdio.h>
void linearsearch(int *str,int numsearch,int n)
 {
   int i,f;
   f=0;
   for(i=0;i<n;i++)
      {
         if(numsearch==str[i])
           { printf("searched number is: %d\n",str[i]);
	     printf("and the position of searched number is %d:\n",i+1);
             f=1;}
      }
   if(f==0)
     printf("number not found\n");
 }

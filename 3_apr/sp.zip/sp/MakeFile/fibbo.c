#include<stdio.h>
void fibbo(int terms)
 {
    int a,b,c,i;
    a = 0;
    b = 1;
    c = 0;
 
    for(i=1; i<=terms; i++)
    {
        printf("%d, ", c);
 
        a = b; 
        b = c; 
        c = a + b; 
    }
	printf("\n");
 }

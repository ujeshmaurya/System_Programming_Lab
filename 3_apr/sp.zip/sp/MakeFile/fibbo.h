void fibbo(int);

void linearsearch(int [],int ,int );

int fib(int n);
int power(int x, unsigned int y);
int xor(int x,int y);
int sum(int arr[], int n);
int largest(int arr[], int n);
int recSearch(int arr[], int l, int r, int x);


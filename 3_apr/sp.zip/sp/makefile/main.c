#include <stdio.h>
#include <string.h>
#include "myheader.h"

int main()
{
    int n,a[100],i,j,k;
    scanf("%d",&n);
    printf("Fibonacci of %d = %d\n\n",n,fib(n));
    scanf("%d %d",&n,&i);
    printf("Power of %d ^ %d = %d\n\n",n,i,power(n,i));
    scanf("%d %d",&n,&i);
    printf("Xor of %d ^ %d = %d\n\n",n,i,xor(n,i));
    scanf("%d",&n);
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    printf("Array:\n");
    for(i=0;i<n;i++)
        printf("%d ",a[i]);
    printf("\n");
    printf("Sum of all elements in array = %d\n\n",sum(a,n));
    printf("Largest element in array = %d\n\n",largest(a,n));
    scanf("%d",&j);
    printf("%d occur in array at %d position\n\n",j,recSearch(a,0,n-1,j));
    return 0;
}

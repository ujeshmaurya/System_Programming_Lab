int xor(int x,int y)
{
    int res=x^y;
    return res;
}
